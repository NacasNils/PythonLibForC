def sayHello():
    for i in range(5):
        print("Hello, world!")
    print("...")
    print("Goodbye!")